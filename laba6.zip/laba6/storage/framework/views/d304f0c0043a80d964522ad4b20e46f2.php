<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <title>MAIN</title>
</head>
<body>
<div class="container">
    <header class="d-flex justify-content-center py-3">
        <ul class="nav nav-pills">
            <li class="nav-item"><a href="<?php echo e(route('main')); ?>" class="nav-link" aria-current="page">Home</a></li>
            <li class="nav-item"><a href="<?php echo e(route('actors')); ?>" class="nav-link active">Actors</a></li>
            <li class="nav-item"><a href="<?php echo e(route('films')); ?>" class="nav-link">Films</a></li>
            <li class="nav-item"><a href="<?php echo e(route('country')); ?>" class="nav-link">Country</a></li>
        </ul>
    </header>
</div>
<div class="album py-5 bg-body-tertiary">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <p class="card-text">Имя: <?php echo e($actor->firstname); ?></p>
                            <p class="card-text">Фамилия: <?php echo e($actor->lastname); ?></p>
                            <p class="card-text">Год рождения: <?php echo e($actor->bithdate); ?></p>
                            <p class="card-text">Страна рождения: <?php echo e($actor->cn_name); ?></p>
                            <div class="list-group">
                                <h1 class="list-group-item list-group-item-action active">Films</h1>

                                    <a href="#" class="list-group-item list-group-item-action"><?php echo e($actor->name); ?></a>


                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</body>
</html>

<?php /**PATH C:\Users\Nikita\OneDrive\Рабочий стол\laba6\resources\views/actors.blade.php ENDPATH**/ ?>