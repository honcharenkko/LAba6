<div>
    <p>First Name: <?php echo e($actors->firstname); ?></p>
    <p>Last Name: <?php echo e($actors->lastname); ?></p>
    <p>Birthdate: <?php echo e($actors->bithdate); ?></p>
    <p>Country: <?php echo e($actors->name); ?></p>
</div>



<?php /**PATH C:\Users\Nikita\OneDrive\Рабочий стол\laba6\resources\views/index.blade.php ENDPATH**/ ?>