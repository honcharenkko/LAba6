<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;


use App\Models\Actor;
use App\Models\Film;
use App\Models\Country;
use Illuminate\Http\Request;

class CountryController extends Controller
{

    public function index()
    {
        $country = DB::table('Country')
            ->leftJoin('Actors', 'cn_id', '=', 'Actors.country')
            ->select('Country.*', 'Actors.firstname', 'Actors.lastname')
            ->get();

        return view('country', ['country' => $country]);
    }

}
