<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;


use App\Models\Actor;
use App\Models\Film;
use App\Models\Country;
use Illuminate\Http\Request;

class FilmsController extends Controller
{
    public function index()
    {
        $films = DB::table('Films')
            ->leftJoin('Actors_Films', 'Films.film_id', '=', 'Actors_Films.film_id')
            ->leftJoin('Actors', 'Actors_Films.actor_id', '=', 'Actors.actor_id')
            ->select('Films.*', 'Actors.firstname', 'Actors.lastname')
            ->get();

        return view('films', ['films' => $films]);



    }

}
