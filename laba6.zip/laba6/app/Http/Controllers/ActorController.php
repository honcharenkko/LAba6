<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;


use App\Models\Actor;
use App\Models\Film;
use App\Models\Country;
use Illuminate\Http\Request;

class ActorController extends Controller
{
    public function index()
    {
        $actors = DB::table('Actors')
            ->leftJoin('Country', 'country', '=', 'Country.cn_id')
            ->leftJoin('Actors_Films', 'Actors.actor_id', '=', 'Actors_Films.actor_id')
            ->leftJoin('Films', 'Actors_Films.film_id', '=', 'Films.film_id')
            ->select('Actors.*', 'Country.cn_name', 'Films.name')
            ->get();

        return view('actors', ['actors' => $actors]);
    }

}
