<?php

namespace App\Http\Controllers;

use App\Models\Actor;
use App\Models\Film;
use App\Models\Country;
use Illuminate\Http\Request;

class MainController extends Controller
{

}
