<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Actors_FilmsController extends BaseController
{
    public function index()
    {
        $afilms = DB::table('Actors_Films')
            ->join('Actors', 'country', '=', 'Country.cn_id')
            ->join('Films', 'film_id', '=', 'Films.film_id')
            ->select('Actors.*', 'Country.name', 'Films.name')
            ->get();

        return view('actors', ['Actors_Films' => $afilms]);
    }
    use AuthorizesRequests, ValidatesRequests;
}
