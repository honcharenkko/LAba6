<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Actor extends Model
{
    protected $table = 'Actors';
    protected $primaryKey = 'actor_id';

    public function country()
    {
        return $this->belongsTo(Country::class, 'cn_id', 'country');
    }

    use HasFactory;
}
