<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <title>MAIN</title>
</head>
<body>
<div class="container">
    <header class="d-flex justify-content-center py-3">
        <ul class="nav nav-pills">
            <li class="nav-item"><a href="{{ route('main') }}" class="nav-link" aria-current="page">Home</a></li>
            <li class="nav-item"><a href="{{ route('actors') }}" class="nav-link">Actors</a></li>
            <li class="nav-item"><a href="{{ route('films') }}" class="nav-link">Films</a></li>
            <li class="nav-item"><a href="{{ route('country') }}" class="nav-link active">Country</a></li>
        </ul>
    </header>
</div>
<div class="album py-5 bg-body-tertiary">
    <div class="container">
        <div class="row">
        @foreach ($country as $countrys)
            <div class="col-md-4">
                <div class="card mb-3">
                    <div class="card-body">
                        <p class="card-text">Название: {{ $countrys->cn_name }}</p>
                        <p class="card-text">Насиление: {{ $countrys->population }}</p>
                        <p class="card-text">Язык: {{ $countrys->language }}</p>
                        <div class="list-group">
                            <h1 class="list-group-item list-group-item-action active">Actors</h1>
                           
                                
                                <a href="#" class="list-group-item list-group-item-action">{{$countrys->firstname}}, {{$countrys->lastname}}</a>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>
</body>
</html>
