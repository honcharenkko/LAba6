<div>
    <p>First Name: {{ $actors->firstname }}</p>
    <p>Last Name: {{ $actors->lastname }}</p>
    <p>Birthdate: {{ $actors->bithdate }}</p>
    <p>Country: {{  $actors->name }}</p>
</div>



